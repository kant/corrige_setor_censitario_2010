﻿drop table temp_geom_ac2;
CREATE table temp_geom_ac2 AS 
SELECT 	cd_geocodi as cod_set, gid, (ST_Dump(geom)).path AS id_dump,
	(ST_Dump(geom)).geom AS geom_dump,
	ST_Transform(  (ST_Dump(geom)).geom  ,32719) AS geom_dump_utm  
FROM "12see250gc_sir";

SELECT topology.DropTopology('topo_AC2a');
SELECT topology.CreateTopology('topo_AC2a',32719);
SELECT topology.addtopogeometrycolumn('topo_AC2a', 'public','temp_geom_ac2','tg_geom_dump_utm2','POLYGON');

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM t_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_ac2 SET tg_geom_dump_utm2 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_AC2a', 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;
/*
WARNING:  Loading of record 118 failed: SQL/MM Spatial exception - geometry crosses edge 3894
WARNING:  Loading of record 123 failed: SQL/MM Spatial exception - geometry crosses edge 3448
WARNING:  Loading of record 68 failed: Could not get geometry of face 1747
WARNING:  Loading of record 263 failed: Could not get geometry of face 1809
WARNING:  Loading of record 775 failed: Could not get geometry of face 1811
********** Error **********

Then the database crasses
*/

a


drop table temp_geom_ac3;
CREATE table temp_geom_ac3 AS 
SELECT 	cd_geocodi as cod_set, gid, (ST_Dump(ST_MakeValid(geom))).path AS id_dump,
	(ST_Dump(ST_MakeValid(geom))).geom AS geom_dump,
	ST_Transform(  (ST_Dump(ST_MakeValid(geom))).geom  ,32719) AS geom_dump_utm  
FROM "12see250gc_sir";


SELECT topology.DropTopology('topo_AC2b');
SELECT topology.CreateTopology('topo_AC2b',32719);
SELECT topology.addtopogeometrycolumn('topo_AC2b', 'public','temp_geom_ac3','tg_geom_dump_utm2','POLYGON');

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM t_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_ac3 SET tg_geom_dump_utm2 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_AC2b', 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;

