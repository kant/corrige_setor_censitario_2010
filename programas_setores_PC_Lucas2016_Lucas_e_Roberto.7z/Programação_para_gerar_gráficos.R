
library(tidyr)
library(dplyr)
library(ggplot2)
setwd('/\\sbsb2\\DPTI\\Usuarios\\Lucas Mation\\Shape_Setor_Censitario_2010_corrrigido\\dados')

###Conectando com banco de dados
library(RPostgreSQL)
con <- dbConnect(dbDriver("PostgreSQL"), host='sbsb4d',
                 port='5432', dbname='dados_espaciais',  password='XXXXX', user='r342471958')

# Lista as tabelas existentes na conex�o
dbListTables(con)

# Lista as colunas de uma determinada tabela
dbListFields(con,"municipios_amazonialegal")

# Retorna uma determinada query
d <- dbGetQuery(con,  "select uf, tags, count(*) as N
                      from tabela_geral_triangulos_validos
                      group by uf, tags ")

d %>% spread(tags,count) -> d2
?spread

####################################################
### Gr�fico de n� de setores censit�rios por UF   ##
####################################################
dados <- read.csv2('setores_por_uf.csv')
dados$uf <- factor(dados$uf)

levels(dados$uf) <- c('RO','AC','AM','RR','PA','AP','TO','MA','PI','CE','RN','PB','PE','AL','SE','BA',
'MG','ES','RJ','SP','PR','SC','RS','MS','MT','GO','DF')

ggplot(dados, aes(x=uf,y=count, fill=tipo)) + geom_bar(stat='identity') +coord_flip() +
ylab('N� de setores censit�rios') + xlab('UF')



####################################################
### Gr�fico de raz�es de invalidade observadas    ##
####################################################

a= data.frame(X1=c("�reas aninhadas\n(Nested Shells)\n",
"Auto_intersec��o\nem anel\n(Ring Self-\nIntersection)\n","Auto-intersec��o\n(Self-Intersection)\n"),X2=c(1,42,9))

ggplot(a, aes(x=X1, y=X2, fill=X1)) + geom_bar(stat='identity') + 
xlab('')+ylab("") + guides(fill=guide_legend(title='Raz�es de\nInvalidade'))+
theme(axis.ticks = element_blank(), axis.text.x = element_blank())

############################################################
### Gr�fico da rela��o de tri�ngulos observados por UF    ##
############################################################
dados <-read.csv2('resultados_pprepair_por_uf.csv')

a <- dados[,c(1,2,8,9,10,11)]

a$Triangles...OK <-a$Triangles...OK/a$Total.triangles*100
a$Triangles...Overlaps<-a$Triangles...Overlaps/a$Total.triangles*100
a$Triangles..Holes<-a$Triangles..Holes/a$Total.triangles*100

a <- a[,-3]
library(reshape2)
a=melt(a, id.vars=c("C�digo.UF", "Unidade.da.Federa��o"))

levels(a$variable)<- c('OK','Sobreposto','Fenda')
levels(a$Unidade.da.Federa��o) <- c('AC','AL','AP','AM','BA','CE',
'DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ',
'RN','RS','RO','RR','SC','SP','SE','TO')

ggplot(a, aes(x=Unidade.da.Federa��o,y=value, fill=variable)) + geom_bar(stat='identity') +coord_flip() +
ylab('% em rela��o ao total de tri�ngulos') + xlab('UF')+
guides(fill=guide_legend(title='Classifica��o do \nTri�ngulo'))






