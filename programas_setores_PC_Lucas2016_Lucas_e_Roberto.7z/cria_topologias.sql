﻿-- download the latest version of postgis-windows from: http://winnie.postgis.net/download/windows/pg94/buildbot/
-- unzip and copy all files to C:\Program Files\PostgreSQL\9.4 folder
-- then run command bellow 
ALTER EXTENSION postgis UPDATE TO "2.2.1dev";

http://blog.mathieu-leplatre.info/use-postgis-topologies-to-clean-up-road-networks.html

SELECT UpdateGeometrySRID('setor_censitaro_2010','geom',4674)


SELECT topology.DropTopology('brasil_sc2010_topo');
SELECT topology.DropTopology('brasil');

drop table AC_sc2010_topo_test;

CREATE table '12see250gc_sir_UTM' AS 
SELECT *, ST_Transform(geom,32719) AS geom_UTM
FROM setor_censitaro_2010  WHERE uf=12;


SELECT UpdateGeometrySRID('12see250gc_sir','geom',4674)


select utmzone(ST_Centroid(geom)), count(*)
FROM ac_sc2010_topo_test
group by utmzone(ST_Centroid(geom))

32719;731
32718;169

4326

create table a12see250gc_sir AS
select * from "12see250gc_sir"

SELECT topology.CreateTopology('brasil',4674);
select topology.addtopogeometrycolumn('brasil', 'public',"a12see250gc_sir",'tg','MULTIPOLYGON');
update 12see250gc_sir set tg = toTopoGeom(ST_Force2D(st_geometryn(geom,1)),'brasil_sc2010_topo', 0.00001);


SELECT topology.CreateTopology('brasil',32719);
select topology.addtopogeometrycolumn('brasil', 'public','12see250gc_sir','tg','MULTIPOLYGON');
update '12see250gc_sir' set tg = toTopoGeom(ST_Force2D(st_geometryn(geom_UTM,1)),'brasil', 1);


********** Error **********


Connection reset.

select * from AC_sc2010_topo_test


select addtopogeometrycolumn('brasil', 'public','brasil_ca_distritos','tg','POLYGON');



SELECT CreateTopology('france_dept_topo', find_srid('public', 'france_dept', 'geom'));
-- Add a layer
SELECT AddTopoGeometryColumn('france_dept_topo', 'public', 'france_dept', 'topogeom', 'MULTIPOLYGON');


[10:32] <LucasBr> I've been stuck for months a project to "clean" topological problens of a shapfile of Brazilian Enumeration Districts (316k polygons). Lots of overlaps and Gaps
[10:33] <LucasBr> Maybe someone here has some guidance
[10:34] <LucasBr> What is the "state of the art" way of creating fixing topological problems
[10:34] <LucasBr> Postgis "CREATE TOPOLOGY" does not work for us. Issues many error messages
[10:35] <LucasBr> We invested quite some time in the stand alone application "pprepair" (run from the terminal)
[10:35] <strk> it's actually "SELECT CreateTopology"
[10:35] <LucasBr> *sorry, you are correct
[10:36] <strk> http://postgis.net/docs/manual-2.1/Topology.html
[10:36] <sigq> Title: Chapter 11. Topology (at postgis.net)
[10:37] <strk> http://strk.keybit.net/blog/2011/11/21/topology-cleaning-with-postgis/
[10:37] <LucasBr> Tks, I've read the topology documentation and tried following some tutorials
[10:37] <LucasBr> But always get an error when creating the topology
[10:38] <LucasBr> The file is full of gaps overlaps and non-noded intersections
[10:38] <LucasBr> Quite large, and covering a large geographical area (Brasil).
[10:38] <LucasBr> So I always get the same errors
[10:40] <LucasBr> polygons sizes and de degree of overlaps and gaps varies a lot over the place
[10:43] <strk> my suggestion is to build it incrementally
[10:43] <strk> how big is the dataset ?
[10:44] <LucasBr> Did anyone ever use pprepair? What was out experience with it? It seems like a great idea, but aparently some errors are recreated when the corrected polygons are exported from the C internal representation, with arbitrary precision (as precise as necessary) to the double precision representation in shapefiles (or postgis)
[10:44] <strk> snapping to a grid can always re-introduce problems
[10:46] <strk> incremental loading in PostGIS gives you a way to clean up the partially loaded topology and continue with the next chunk
[10:46] <LucasBr> if I'm not mistaken it is 350mb
[10:46] <strk> up to cleaning after every single insertion
[10:47] <LucasBr> the files are here: ftp://geoftp.ibge.gov.br/malhas_digitais/censo_2010/setores_censitarios
[10:47] <strk> or you can try with the ISO http://postgis.net/docs/manual-2.1/ST_CreateTopoGeo.html
[10:47] <sigq> Title: ST_CreateTopoGeo (at postgis.net)
[10:47] <strk> which loads it all in memory, nodes it in memory and then moves on to populate the topology
[10:49] <LucasBr> @strk: did you ever try pprepair?
[10:49] -sigq- Error: "strk:" is not a valid command.
[10:49] <LucasBr> strk: did you ever try pprepair?
[10:50] <strk> nope
[10:52] <strk> select addtopogeometrycolumn('brasil', 'public','brasil_ca_distritos','tg','POLYGON');
[10:54] <LucasBr> if you are ever curious about pprepair take a look at: https://3d.bk.tudelft.nl/ken/files/12_pfg.pdf  (I am not the author, but seems very related to your work)
[10:54] <strk> update brasil_ca_distritos set tg = toTopoGeom(ST_Force2D(st_geometryn(geom,1)), 'brasil', 1) where gid < 100; -- works
[10:54] <strk> there are actually 23 polygons in that one, which means that's a complete load
[10:54] <strk> which file did fail for you exactly ?
[10:54] <strk> (I know about pprepair, just never tested)
[10:55] == n_e_o [~neo@106.51.130.134] has joined #postgis
[10:56] <LucasBr> you are using the distritos one
[10:56] <strk> select face_id from brasil.face where face_id > 0 and ST_Area(ST_GetFaceGeometry('brasil', face_id)) < 1e-8; -- 30 rows found
[10:56] <strk> -rw-rw-r--    1 ftp      ftp       1186136 Jul 28 13:14 ac_distritos.zip
[10:56] <strk> -rw-rw-r--    1 ftp      ftp       1187893 Jul 28 13:14 ac_municipios.zip
[10:56] <strk> -rw-rw-r--    1 ftp      ftp       3640402 Jul 28 13:14 ac_setores_censitarios.zip
[10:56] <strk> -rw-rw-r--    1 ftp      ftp       1189184 Jul 28 13:14 ac_subdistritos.zip
[10:56] <strk> gotta leave, might try ac_setores_censitarios.zip later (or never :)
[10:56] <LucasBr> it should be the "*_setores_censitarios" file
[10:57] <strk> anyway, try the gid filter to load incrementally
[10:57] <LucasBr> tks,
[10:57] <strk> skip the block you can't load, and get to them later
[10:57] <LucasBr> I'll try and report back here
[10:57] <strk> with the UPDATE approach it's easier as you leave NULLs in the still-to-load rows
[10:57] <strk> consider also the mailing list, easier :)
[10:57] <LucasBr> user or dev?
[10:58] <LucasBr> the postgis-user? or postgis-dev list?
[10:59] <LucasBr> ok, anyway, tks a lot for all the suggestions guys. I'll try to implement it and get back to you.
[11:01] <strk> either one :)
[11:12] == sigq [~supybot@qgis/bot/sigq] has quit [Remote host closed the connection]
[11:12] == sigq [~supybot@qgis/bot/sigq] has joined #postgis