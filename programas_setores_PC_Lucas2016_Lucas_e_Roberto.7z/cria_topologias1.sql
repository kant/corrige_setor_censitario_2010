﻿
	


drop table ac_sc2010_topo_test;
CREATE table ac_sc2010_topo_test AS 
SELECT *, ST_Transform(geom,32719) AS geom_UTM
FROM setor_censitaro_2010  WHERE uf=12;

drop table ac_sc2010_topo_dump;
CREATE table ac_sc2010_topo_dump AS 
SELECT 	gid, id, cod_set, (ST_Dump(geom)).path AS id_dump, (ST_Dump(geom)).geom AS geom_dump
FROM AC_sc2010_topo_test;







---------------------------
-- creating topology from the corrected geoms

select * from setores_censitario_pprepair_final_r limit 1
select ST_SRID(geom)
from (select * from setores_censitario_pprepair_final_r limit 1) AS foo


geom_ppr_rep_sVW_10m

-- select AC and dump

select * from ac_pprepair_topo_dump limit 1

DROP TABLE ac_pprepair_topo_dump;
CREATE TABLE ac_pprepair_topo_dump AS
SELECT 	uf, cod_set, gid, (ST_Dump(geom_ppr_rep_sVW_10m)).path AS id_dump, 
	(ST_Dump(geom_ppr_rep_sVW_10m)).geom AS geom_ppr_rep_sVW_10m_dump, 
	ST_Transform(  (ST_Dump(geom_ppr_rep_sVW_10m)).geom  ,32719) AS geom_ppr_rep_sVW_10m_dump_UTM 
FROM 	(SELECT a.*, b.gid
	FROM 	(SELECT * FROM setores_censitario_pprepair_final_r WHERE uf=12) AS a
	INNER JOIN (SELECT * FROM setor_censitaro_2010 WHERE uf=12)	AS b
	ON a.cod_set = b.cod_set) AS c;





-- topology
ALTER TABLE ac_pprepair_topo_dump DROP COLUMN tg_ppr2

SELECT topology.DropTopology('brasil_ppr2');
SELECT topology.CreateTopology('brasil_ppr2',4326);
select topology.addtopogeometrycolumn('brasil_ppr2', 'public','ac_pprepair_topo_dump','tg_ppr2','POLYGON');
UPDATE ac_pprepair_topo_dump SET tg_ppr2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr2', 1, 0.00001) ;
-- ERROR:  SQL/MM Spatial exception - geometry crosses edge 153
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM ac_pprepair_topo_dump LOOP
    BEGIN
      UPDATE ac_pprepair_topo_dump SET tg_ppr2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr2', 1, 0.00001)
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;


SELECT topology.DropTopology('brasil_ppr3');
SELECT topology.CreateTopology('brasil_ppr3',4326);
select topology.addtopogeometrycolumn('brasil_ppr3', 'public','ac_pprepair_topo_dump','tg_ppr3','POLYGON');
UPDATE ac_pprepair_topo_dump SET tg_ppr3 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr3', 1) ;
-- ERROR:  Spatial exception - geometry intersects edge 196
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM ac_pprepair_topo_dump LOOP
    BEGIN
      UPDATE ac_pprepair_topo_dump SET tg_ppr3 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr3', 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;





update ac_pprepair_topo_dump set tg_ppr = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr', 1) where gid< 5;
--ERROR:  Invalid edge (no two distinct vertices exist)
--CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
--PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
--********** Error **********

update ac_pprepair_topo_dump set tg_ppr = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr', 1, 0.00001) where gid< 7;
--Query returned successfully: 6 rows affected, 174 ms execution time.
update ac_pprepair_topo_dump set tg_ppr = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump),'brasil_ppr', 1, 0.0001) where gid< 10;
--ERROR:  SQL/MM Spatial exception - geometry crosses edge 10
--CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
--PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment


SELECT topology.DropTopology('brasil_ppr_utm');
SELECT topology.CreateTopology('brasil_ppr_utm',32719);
select topology.addtopogeometrycolumn('brasil_ppr_utm', 'public','ac_pprepair_topo_dump','tg_ppr_utm','POLYGON');
update ac_pprepair_topo_dump set tg_ppr_utm = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm', 1, 1) where gid< 10;
--ERROR:  SQL/MM Spatial exception - curve not simple
--CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
--PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm', 1, 5) where gid< 5;
-- Query returned successfully: 3 rows affected, 71 ms execution time.
update ac_pprepair_topo_dump set tg_ppr_utm = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm', 1, 5) where gid< 100;
-- crashes the data base

update ac_pprepair_topo_dump set tg_ppr_utm = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm', 1, 5) where gid IN (6);
-- Query returned successfully: one row affected, 637 ms execution time.
update ac_pprepair_topo_dump set tg_ppr_utm = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm', 1, 5) where gid IN (7);
-- ERROR:  SQL/MM Spatial exception - curve not simple
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment


select count(*) from ac_pprepair_topo_dump




SELECT topology.DropTopology('brasil_ppr_utm2');
SELECT topology.CreateTopology('brasil_ppr_utm2',32719);
select topology.addtopogeometrycolumn('brasil_ppr_utm2', 'public','ac_pprepair_topo_dump','tg_ppr_utm2','POLYGON');
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=800 AND gid< 825;

update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1)
-- ERROR:  SQL/MM Spatial exception - geometry crosses edge 582
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

-- going by 100 chunks:
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=700 AND gid< 800;
-- everything worked up to 800. Query returned successfully: 103 rows affected, 26543 ms execution time.

update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=800 AND gid< 900;
-- ERROR:  Spatial exception - geometry intersects edge 3531
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=800 AND gid< 900;
-- ERROR:  Spatial exception - geometry intersects edge 3531
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=800 AND gid< 850;
-- ERROR:  Spatial exception - geometry intersects edge 3607
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=825 AND gid< 850;
-- ERROR:  Spatial exception - geometry intersects edge 3683
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=825 AND gid< 837;
-- ERROR:  Spatial exception - geometry intersects edge 3683
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=825 AND gid< 831;
-- ERROR:  Spatial exception - geometry intersects edge 3683
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=825 AND gid< 828;
-- ERROR:  Spatial exception - geometry intersects edge 3683
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid=826 
-- ERROR:  Spatial exception - geometry intersects edge 3683
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment
-- ********** Error **********

update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=827 AND gid< 900;
-- Query returned successfully: 75 rows affected, 17739 ms execution time.
update ac_pprepair_topo_dump set tg_ppr_utm2 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm2', 1, 1) where gid>=900 AND gid< 921;
-- Query returned successfully: one row affected, 116 ms execution time.

SELECT topology.DropTopology('brasil_ppr_utm3');
SELECT topology.CreateTopology('brasil_ppr_utm3',32719);
select topology.addtopogeometrycolumn('brasil_ppr_utm3', 'public','ac_pprepair_topo_dump','tg_ppr_utm3','POLYGON');
update ac_pprepair_topo_dump set tg_ppr_utm3 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm3', 1) ;
-- ERROR:  SQL/MM Spatial exception - geometry crosses edge 3130
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM ac_pprepair_topo_dump LOOP
    BEGIN
      UPDATE ac_pprepair_topo_dump SET tg_ppr_utm3 = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_10m_dump_UTM),'brasil_ppr_utm3', 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;

WARNING:  Loading of record 361 failed: SQL/MM Spatial exception - geometry crosses edge 3569
WARNING:  Loading of record 799 failed: SQL/MM Spatial exception - geometry crosses edge 8187
WARNING:  Loading of record 825 failed: Spatial exception - geometry intersects edge 8501
WARNING:  Loading of record 826 failed: SQL/MM Spatial exception - geometry crosses edge 8450
WARNING:  Loading of record 307 failed: Spatial exception - geometry intersects edge 6809
WARNING:  Loading of record 154 failed: SQL/MM Spatial exception - geometry crosses edge 10400
Query returned successfully with no result in 169471 ms.

create table aaa_temp as 
select * from ac_pprepair_topo_dump where gid = 826




ERROR:  malformed record literal: "brasil"
LINE 1: ... tg = toTopoGeom(ST_Force2D(st_geometryn(geom,1)),'brasil', ...
                                                             ^
DETAIL:  Missing left parenthesis.


********** Error **********


Connection reset.



select * from AC_sc2010_topo_test
select addtopogeometrycolumn('brasil', 'public','brasil_ca_distritos','tg','POLYGON');

SELECT CreateTopology('france_dept_topo', find_srid('public', 'france_dept', 'geom'));
-- Add a layer
SELECT AddTopoGeometryColumn('france_dept_topo', 'public', 'france_dept', 'topogeom', 'MULTIPOLYGON');



