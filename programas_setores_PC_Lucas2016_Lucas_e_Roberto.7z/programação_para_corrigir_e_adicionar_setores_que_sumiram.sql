/* Criando um tabela de seguranca para caso haja erro no processo */
CREATE TABLE setores_censitario_pprepair_final_reparado_copia_seguranca_antes_de_adicionar_set  AS
SELECT * FROM setores_censitario_pprepair_final_reparado;

/* Identificando casos de setores com areas muito pequenas de maneira nao justificada*/
SELECT cd_geocodi, tipo,ST_Area( ST_Transform( geom,utmzone( ST_Centroid(geom) ) ) ) as area_setor 
        FROM setores_censitario_pprepair_final_reparado
        WHERE ST_Area( ST_Transform( geom,utmzone( ST_Centroid(geom) ) ) ) <10

/* Deletando esses casso de areas erradas para depois serem inseridos */        
DELETE FROM setores_censitario_pprepair_final_reparado 
    USING (SELECT cd_geocodi, tipo,ST_Area( ST_Transform( geom,utmzone( ST_Centroid(geom) ) ) ) as area_setor 
        FROM setores_censitario_pprepair_final_reparado
        WHERE ST_Area( ST_Transform( geom,utmzone( ST_Centroid(geom) ) ) ) <10) AS foo
    WHERE setores_censitario_pprepair_final_reparado.cd_geocodi=foo.cd_geocodi;

/* Criando ma tabela temporario com as interseccoes entre os setores que sumiram com a shape reparado para */
/* identificar local onde inserir esses setores*/ 
CREATE TABLE temp_tabela_interseccoes AS 
SELECT tab1.cd_geocodi AS cd_geocodi_no_reparado, tab2.cd_geocodi AS cd_geocodi_no_original, 
    ST_Intersection(tab1.geom,tab2.geomcorrigido), 
    GeometryType(ST_Intersection(tab1.geom,tab2.geomcorrigido)) 
FROM setores_censitario_pprepair_final_reparado AS tab1,
    (SELECT a.* 
    FROM setores_censitario_brasil AS a,
        (SELECT foo2.cd_geocodi,foo1.count FROM
        (SELECT cd_geocodi,count(*) FROM setores_censitario_pprepair_final_reparado GROUP BY cd_geocodi) AS foo1
        FULL OUTER JOIN
        (SELECT cd_geocodi,count(*) FROM setores_censitario_brasil GROUP BY cd_geocodi) AS foo2
        ON foo2.cd_geocodi = foo1.cd_geocodi
        WHERE foo1.count IS NULL) AS foo
    WHERE a.cd_geocodi = foo.cd_geocodi) as tab2
WHERE (tab1.uf=29 OR tab1.uf=35) AND tab1.uf = tab2.uf AND ST_Intersects(tab1.geom,tab2.geomcorrigido)

/* Criando uma tabela temporario com os setores que sumiram a partir da tabela original */
CREATE TABLE temp_tabela_casos_sumidos as
SELECT a.* 
    FROM setores_censitario_brasil AS a,
        (SELECT foo2.cd_geocodi,foo1.count FROM
        (SELECT cd_geocodi,count(*) FROM setores_censitario_pprepair_final_reparado GROUP BY cd_geocodi) AS foo1
        FULL OUTER JOIN
        (SELECT cd_geocodi,count(*) FROM setores_censitario_brasil GROUP BY cd_geocodi) AS foo2
        ON foo2.cd_geocodi = foo1.cd_geocodi
        WHERE foo1.count IS NULL) AS foo
    WHERE a.cd_geocodi = foo.cd_geocodi

/* Atualizando a tabela temporaria de interseccoes para extrair a parte de poligono em casos de GEOMETRYCOLLECTION*/
UPDATE temp_tabela_interseccoes
SET st_intersection = ST_CollectionExtract(st_intersection,3)
WHERE geometrytype = 'GEOMETRYCOLLECTION';

/* Retirando o caso estranho na Bahia que sera desconsiderado */
SELECT * FROM temp_tabela_interseccoes ORDER BY cd_geocodi_no_original;
DELETE FROM temp_tabela_interseccoes WHERE cd_geocodi_no_original = '291800110000001';

SELECT * FROM temp_tabela_casos_sumidos ORDER BY cd_geocodi;
DELETE FROM temp_tabela_casos_sumidos WHERE cd_geocodi = '291800110000001';

/* Criando os novos geoms que serao as diferencas */
CREATE TABLE temp_tabela_novos_geoms AS 
SELECT foo.cd_geocodi_no_reparado AS cd_geocodi, ST_Difference(a.geom,foo.geom) as geom FROM setores_censitario_pprepair_final_reparado AS a,
(SELECT cd_geocodi_no_reparado, ST_Union(st_intersection) as geom FROM temp_tabela_interseccoes 
WHERE geometrytype in ('POLYGON','MULTIPOLYGON','GEOMETRYCOLLECTION')
GROUP BY cd_geocodi_no_reparado) AS foo
WHERE foo.cd_geocodi_no_reparado = a.cd_geocodi

/* Atualizando a tabela reparada para criar os espacos onde serao inseridos os casos sumidos*/
UPDATE setores_censitario_pprepair_final_reparado
SET geom = foo.geom
FROM (SELECT cd_geocodi, ST_Multi(geom) as geom FROM temp_tabela_novos_geoms) AS foo
WHERE foo.cd_geocodi = setores_censitario_pprepair_final_reparado.cd_geocodi;

CREATE TABLE temp_tabela_nova_infos AS
select * from temp_tabela_casos_sumidos;

ALTER TABLE temp_tabela_nova_infos
DROP COLUMN id;
ALTER TABLE temp_tabela_nova_infos
DROP COLUMN geom;
ALTER TABLE temp_tabela_nova_infos
DROP COLUMN uf;

ALTER TABLE temp_tabela_nova_infos
RENAME COLUMN geomcorrigido to geom;

ALTER TABLE temp_tabela_nova_infos
ADD COLUMN uf numeric;
UPDATE temp_tabela_nova_infos
SET uf = cast(substring(cd_geocodi FROM 1 FOR 2) as numeric);

SELECT max(gid) FROM setores_censitario_pprepair_final_reparado

UPDATE temp_tabela_nova_infos
SET gid = gid + 323040;

INSERT INTO setores_censitario_pprepair_final_reparado
SELECT * FROM temp_tabela_nova_infos;

SELECT count(*) FROM setores_censitario_pprepair_final_reparado

SELECT COUNT(*), ST_IsValid(geom) from setores_censitario_pprepair_final_reparado group by ST_IsValid(geom);
SELECT COUNT(*), GeometryType(geom) from setores_censitario_pprepair_final_reparado group by GeometryType(geom);

CLUSTER setores_censitario_pprepair_final_reparado USING spatial_index_2;

SELECT uf, ST_Union(geom) FROM setores_censitario_pprepair_final_reparado GROUP BY uf ORDER BY uf;

DROP TABLE temp_tabela_interseccoes;
DROP TABLE temp_tabela_casos_sumidos;
DROP TABLE temp_tabela_novos_geoms;
DROP TABLE temp_tabela_nova_infos;
/* ******************* */
/* ******************* */
