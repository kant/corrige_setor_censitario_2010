/* Create a new table that will receive repaired polygons */
CREATE TABLE pprepairnew_macvirtual_setores_reparado AS
SELECT * FROM pprepairnew_macvirtual_setores;

/* Create spatial index and reorder table */
CREATE INDEX spatial_index_mac ON pprepairnew_macvirtual_setores_reparado USING GIST (uf,geom); 
CLUSTER pprepairnew_macvirtual_setores_reparado USING spatial_index_mac;
ANALYZE pprepairnew_macvirtual_setores_reparado;

/* Delete cases of 'MULTIPOINT','MULTILINESTRING','LINESTRING','POINT', these polygons were produced in pprepair process */
DELETE FROM pprepairnew_macvirtual_setores_reparado 
    USING (SELECT * FROM pprepairnew_macvirtual_setores
        WHERE GeometryType(ST_MakeValid(geom)) IN ('MULTIPOINT','MULTILINESTRING','LINESTRING','POINT')) AS foo
    WHERE pprepairnew_macvirtual_setores_reparado.gid=foo.gid;

/* Count number of rows in the table for control */
SELECT count(*) FROM pprepairnew_macvirtual_setores_reparado;

/* Update geom information with the command ST_MakeValid, to ensure that all polygons has valid geometries */
UPDATE pprepairnew_macvirtual_setores_reparado
SET geom = ST_MakeValid(geom)
WHERE GeometryType(ST_MakeValid(geom)) = 'MULTIPOLYGON';

 /* In cases that St_MakeValid produces GEOMETRYCOLLECTION, extract only the polygon part */
 UPDATE pprepairnew_macvirtual_setores_reparado
 SET geom = ST_CollectionExtract(ST_MakeValid(geom),3)
 WHERE GeometryType(ST_MakeValid(geom)) = 'GEOMETRYCOLLECTION';

/* Identify cases of duplication of cd_geocodi */
SELECT * 
FROM (SELECT count(*),cd_geocodi FROM pprepairnew_macvirtual_setores_reparado 
      GROUP BY cd_geocodi) AS foo
WHERE count > 1
ORDER BY count DESC;

/* Make ST_Union for cases of duplication of cd_geocodi */
SELECT min(gid) as gid,cd_geocodi,ST_Multi(ST_Union(ST_MakeValid(geom))) AS geom 
FROM (SELECT pprepairnew_macvirtual_setores_reparado.* 
      FROM pprepairnew_macvirtual_setores_reparado,
           (SELECT count(*),cd_geocodi FROM pprepairnew_macvirtual_setores_reparado
       GROUP BY cd_geocodi) AS foo
      WHERE foo.count > 1 AND pprepairnew_macvirtual_setores_reparado.cd_geocodi=foo.cd_geocodi) AS foo
GROUP BY cd_geocodi;

/*Replace the geom information in one case of each duplication using ST_Union information calculated previously*/
UPDATE pprepairnew_macvirtual_setores_reparado
SET geom = foo.geom
FROM (SELECT min(gid) as gid,cd_geocodi,ST_Multi(ST_Union(ST_MakeValid(geom))) AS geom FROM 
    (SELECT pprepairnew_macvirtual_setores_reparado.* FROM pprepairnew_macvirtual_setores_reparado,
        (SELECT count(*),cd_geocodi FROM pprepairnew_macvirtual_setores_reparado
        GROUP BY cd_geocodi) AS foo
    WHERE foo.count > 1 AND pprepairnew_macvirtual_setores_reparado.cd_geocodi=foo.cd_geocodi) AS foo
    GROUP BY cd_geocodi) as foo
WHERE foo.gid=pprepairnew_macvirtual_setores_reparado.gid;

/*Delete cases of cd_geocodi duplication, except the case that received ST_Union information*/
DELETE FROM pprepairnew_macvirtual_setores_reparado 
USING
    (SELECT foo2.min_gid,foo.* FROM
    (SELECT pprepairnew_macvirtual_setores_reparado.* FROM pprepairnew_macvirtual_setores_reparado,
        (SELECT count(*),cd_geocodi FROM pprepairnew_macvirtual_setores_reparado
        GROUP BY cd_geocodi) AS foo
    WHERE foo.count > 1 AND pprepairnew_macvirtual_setores_reparado.cd_geocodi=foo.cd_geocodi) AS foo
    FULL OUTER JOIN
    (SELECT min(gid) as min_gid FROM 
    (SELECT pprepairnew_macvirtual_setores_reparado.* FROM pprepairnew_macvirtual_setores_reparado,
        (SELECT count(*),cd_geocodi FROM pprepairnew_macvirtual_setores_reparado
        GROUP BY cd_geocodi) AS foo
    WHERE foo.count > 1 AND pprepairnew_macvirtual_setores_reparado.cd_geocodi=foo.cd_geocodi) AS foo
    GROUP BY cd_geocodi) as foo2
    ON
    foo2.min_gid = foo.gid
    WHERE foo2.min_gid IS NULL) AS foo
WHERE pprepairnew_macvirtual_setores_reparado.gid=foo.gid;

/* Checking if is there any case of cd_geocodi duplication */
SELECT * FROM
(SELECT cd_geocodi,count(*) FROM pprepairnew_macvirtual_setores_reparado GROUP BY cd_geocodi) AS foo
WHERE count>1

/* Checking geometry types of the polygons */ 
SELECT count(*), GeometryType(ST_MakeValid(geom)) FROM pprepairnew_macvirtual_setores_reparado
GROUP BY GeometryType(ST_MakeValid(geom))

/* Checking if all polygons are valid */
SELECT count(*),IsValid(geom) FROM pprepairnew_macvirtual_setores_reparado
GROUP BY IsValid(geom);

/* Drop id column from table because it's not unique and can generate problems */
ALTER TABLE pprepairnew_macvirtual_setores_reparado
DROP COLUMN id;

/* Reorder table once again */
CLUSTER pprepairnew_macvirtual_setores_reparado USING spatial_index_mac;
ANALYZE pprepairnew_macvirtual_setores_reparado;

/* ********************************************************* */

SELECT uf,ST_Union(ST_MakeValid(geom)) 
FROM pprepairnew_macvirtual_setores_reparado
GROUP BY uf