﻿select * from temp_geom_bahia2
where abs(ST_Area(geom_dump_utm)-ST_Area(tg_geom_dump_utm_bahia)) > 0
order by abs(ST_Area(geom_dump_utm)-ST_Area(tg_geom_dump_utm_bahia)) 
limit 10

create table tabela_teste as
select *,abs(ST_Area(geom_dump_utm)-ST_Area(tg_geom_dump_utm_bahia)) from temp_geom_bahia2
where abs(ST_Area(geom_dump_utm)-ST_Area(tg_geom_dump_utm_bahia)) > 0
order by abs(ST_Area(geom_dump_utm)-ST_Area(tg_geom_dump_utm_bahia)) desc
limit 20
