﻿/* rename tabela antiga */
ALTER TABLE temp_geom_bahia RENAME TO temp_geom_bahia2; 

/* criando nova tabela */
CREATE TABLE temp_geom_bahia AS
SELECT 	uf, cod_set, gid, (ST_Dump(ST_MakeValid(geom))).path AS id_dump,
	(ST_Dump(ST_MakeValid(geom))).geom AS geom_dump,
	ST_Transform(  (ST_Dump(ST_MakeValid(geom))).geom  ,32724) AS geom_dump_UTM  
FROM setor_censitaro_2010 WHERE uf=29;


-- 1) UTM, 1m tolerance

SELECT topology.DropTopology('topo_bahia');
SELECT topology.CreateTopology('topo_bahia',32724);
SELECT topology.addtopogeometrycolumn('topo_bahia', 'public','temp_geom_bahia','tg_geom_dump_utm','POLYGON');
UPDATE temp_geom_bahia SET tg_geom_dump_utm = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia', 1, 1) ;
-- ERROR:  Spatial exception - geometry intersects edge 20187
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_bahia SET tg_geom_dump_utm = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia', 1, 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;

/*
WARNING:  Loading of record 23139 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 23174 failed: Spatial exception - geometry intersects edge 20671
WARNING:  Loading of record 1 failed: Spatial exception - geometry intersects edge 52907
WARNING:  Loading of record 14853 failed: Spatial exception - geometry intersects edge 53514
WARNING:  Loading of record 1918 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 566 failed: SQL/MM Spatial exception - curve not simple
WARNING:  Loading of record 233 failed: Spatial exception - geometry intersects edge 73281
WARNING:  Loading of record 1702 failed: Spatial exception - geometry intersects edge 73349
WARNING:  Loading of record 300 failed: Spatial exception - geometry intersects edge 74710
WARNING:  Loading of record 23182 failed: Spatial exception - geometry intersects edge 20237
WARNING:  Loading of record 23202 failed: Spatial exception - geometry intersects edge 20696
WARNING:  Loading of record 23131 failed: Spatial exception - geometry intersects edge 20646
WARNING:  Loading of record 23135 failed: Spatial exception - geometry intersects edge 20656
WARNING:  Loading of record 23138 failed: Spatial exception - geometry intersects edge 75063
WARNING:  Loading of record 23144 failed: Spatial exception - geometry intersects edge 75092
WARNING:  Loading of record 23155 failed: Spatial exception - geometry intersects edge 20899
WARNING:  Loading of record 23163 failed: Spatial exception - geometry intersects edge 75117
WARNING:  Loading of record 23164 failed: Spatial exception - geometry intersects edge 75121
WARNING:  Loading of record 23166 failed: Spatial exception - geometry intersects edge 20875
WARNING:  Loading of record 23178 failed: SQL/MM Spatial exception - geometry crosses edge 75150
WARNING:  Loading of record 22764 failed: Spatial exception - geometry intersects edge 21617
WARNING:  Loading of record 17349 failed: Spatial exception - geometry intersects edge 40994
WARNING:  Loading of record 11261 failed: Spatial exception - geometry intersects edge 48826
WARNING:  Loading of record 6659 failed: Spatial exception - geometry intersects edge 74509
WARNING:  Loading of record 217 failed: Spatial exception - geometry intersects edge 75321
WARNING:  Loading of record 275 failed: Spatial exception - geometry intersects edge 61858
WARNING:  Loading of record 325 failed: SQL/MM Spatial exception - geometry crosses edge 54252
WARNING:  Loading of record 225 failed: Spatial exception - geometry intersects edge 75766
WARNING:  Loading of record 301 failed: Spatial exception - geometry intersects edge 75787
WARNING:  Loading of record 1890 failed: Spatial exception - geometry intersects edge 75878
WARNING:  Loading of record 1703 failed: Spatial exception - geometry intersects edge 75435
WARNING:  Loading of record 1706 failed: Spatial exception - geometry intersects edge 73360
WARNING:  Loading of record 1879 failed: Spatial exception - geometry intersects edge 55393
WARNING:  Loading of record 1880 failed: Spatial exception - geometry intersects edge 81523
WARNING:  Loading of record 1898 failed: Spatial exception - geometry intersects edge 81971
WARNING:  Loading of record 1947 failed: Spatial exception - geometry intersects edge 84589
WARNING:  Loading of record 1958 failed: Spatial exception - geometry intersects edge 84667
WARNING:  Loading of record 1961 failed: Spatial exception - geometry intersects edge 75889
WARNING:  Loading of record 1967 failed: Spatial exception - geometry intersects edge 75396
WARNING:  Loading of record 1959 failed: Spatial exception - geometry intersects edge 55299
WARNING:  Loading of record 1907 failed: Spatial exception - geometry intersects edge 55267
WARNING:  Loading of record 5938 failed: SQL/MM Spatial exception - geometry crosses edge 86112
WARNING:  Loading of record 5937 failed: SQL/MM Spatial exception - geometry crosses edge 86112
WARNING:  Loading of record 5616 failed: Spatial exception - geometry intersects edge 87384
WARNING:  Loading of record 5445 failed: Spatial exception - geometry intersects edge 87331
WARNING:  Loading of record 1917 failed: Spatial exception - geometry intersects edge 84662
WARNING:  Loading of record 23206 failed: Spatial exception - geometry intersects edge 20753
WARNING:  Loading of record 23132 failed: Spatial exception - geometry intersects edge 20634
WARNING:  Loading of record 20235 failed: Spatial exception - geometry intersects edge 84320
WARNING:  Loading of record 18381 failed: Spatial exception - geometry intersects edge 37768
WARNING:  Loading of record 286 failed: Spatial exception - geometry intersects edge 74556
WARNING:  Loading of record 2570 failed: Spatial exception - geometry intersects edge 92423
WARNING:  Loading of record 17673 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 23180 failed: Spatial exception - geometry intersects edge 90220
WARNING:  Loading of record 23181 failed: Spatial exception - geometry intersects edge 95304
Query returned successfully with no result in 12751787 ms.

~53 erros...
*/


-- 2) UTM, no tolerance

SELECT topology.DropTopology('topo_bahia2');
SELECT topology.CreateTopology('topo_bahia2',32724);
SELECT topology.addtopogeometrycolumn('topo_bahia2', 'public','temp_geom_bahia','tg_geom_dump_utm2','POLYGON');
UPDATE temp_geom_bahia SET tg_geom_dump_utm2 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia2', 1) ;
-- ERROR:  Could not get geometry of face 13901
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_bahia SET tg_geom_dump_utm2 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia2', 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;
/*

*/


/* ********************************************* */
/* ********************************************* */


-- 3) SIRGAS 2000 and 0.00001 degree tolerance 

--ALTER TABLE temp_geom_bahia DROP COLUMN tg_geom_dump;
SELECT topology.DropTopology('topo_bahia3');
SELECT topology.CreateTopology('topo_bahia3',4674);
select topology.addtopogeometrycolumn('topo_bahia3', 'public','temp_geom_bahia','tg_geom_dump','POLYGON');
update temp_geom_bahia set tg_geom_dump = toTopoGeom(ST_Force2D(geom_dump),'topo_bahia3', 1, 0.00001) ;
-- ERROR:  Spatial exception - geometry intersects edge 4849
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_bahia SET tg_geom_dump = toTopoGeom(ST_Force2D(geom_dump),'topo_bahia3', 1, 0.00001) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;

/*
WARNING:  Loading of record 5309 failed: Spatial exception - geometry intersects edge 3566
WARNING:  Loading of record 1952 failed: SQL/MM Spatial exception - geometry crosses edge 5687
WARNING:  Loading of record 5911 failed: SQL/MM Spatial exception - geometry crosses edge 7175
WARNING:  Loading of record 7149 failed: Spatial exception - geometry intersects edge 19045
WARNING:  Loading of record 1914 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 566 failed: SQL/MM Spatial exception - curve not simple
WARNING:  Loading of record 1954 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 24084 failed: SQL/MM Spatial exception - geometry crosses edge 11050
WARNING:  Loading of record 24096 failed: Spatial exception - geometry intersects edge 24873
WARNING:  Loading of record 23222 failed: Spatial exception - geometry intersects edge 27414
WARNING:  Loading of record 23185 failed: Spatial exception - geometry intersects edge 27617
WARNING:  Loading of record 23227 failed: Spatial exception - geometry intersects edge 11277
WARNING:  Loading of record 23182 failed: Spatial exception - geometry intersects edge 27383
WARNING:  Loading of record 23202 failed: Spatial exception - geometry intersects edge 27725
WARNING:  Loading of record 23128 failed: Spatial exception - geometry intersects edge 11286
WARNING:  Loading of record 23131 failed: Spatial exception - geometry intersects edge 27797
WARNING:  Loading of record 23135 failed: Spatial exception - geometry intersects edge 27821
WARNING:  Loading of record 23138 failed: Spatial exception - geometry intersects edge 27766
WARNING:  Loading of record 23140 failed: Spatial exception - geometry intersects edge 27886
WARNING:  Loading of record 23144 failed: Spatial exception - geometry intersects edge 11287
WARNING:  Loading of record 23155 failed: Spatial exception - geometry intersects edge 28029
WARNING:  Loading of record 23156 failed: Spatial exception - geometry intersects edge 28024
WARNING:  Loading of record 23160 failed: Spatial exception - geometry intersects edge 28054
WARNING:  Loading of record 23163 failed: Spatial exception - geometry intersects edge 27239
WARNING:  Loading of record 23164 failed: Spatial exception - geometry intersects edge 28111
WARNING:  Loading of record 23166 failed: Spatial exception - geometry intersects edge 28146
WARNING:  Loading of record 23173 failed: Spatial exception - geometry intersects edge 28196
WARNING:  Loading of record 23178 failed: Spatial exception - geometry intersects edge 28022
WARNING:  Loading of record 22764 failed: Spatial exception - geometry intersects edge 28727
WARNING:  Loading of record 17147 failed: Spatial exception - geometry intersects edge 40197
WARNING:  Loading of record 17349 failed: Spatial exception - geometry intersects edge 44506
WARNING:  Loading of record 11261 failed: Spatial exception - geometry intersects edge 50221
WARNING:  Loading of record 11309 failed: SQL/MM Spatial exception - geometry crosses a node
WARNING:  Loading of record 11213 failed: SQL/MM Spatial exception - geometry crosses edge 50510
WARNING:  Loading of record 6659 failed: Spatial exception - geometry intersects edge 68449
WARNING:  Loading of record 261 failed: Spatial exception - geometry intersects edge 19297
WARNING:  Loading of record 304 failed: Spatial exception - geometry intersects edge 19462
WARNING:  Loading of record 215 failed: Spatial exception - geometry intersects edge 71394
WARNING:  Loading of record 217 failed: Spatial exception - geometry intersects edge 71403
WARNING:  Loading of record 4 failed: Spatial exception - geometry intersects edge 71442
WARNING:  Loading of record 235 failed: Spatial exception - geometry intersects edge 19302
WARNING:  Loading of record 267 failed: Spatial exception - geometry intersects edge 71835
WARNING:  Loading of record 2550 failed: Spatial exception - geometry intersects edge 24677
WARNING:  Loading of record 1883 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 1891 failed: Spatial exception - geometry intersects edge 72560
WARNING:  Loading of record 1704 failed: Spatial exception - geometry intersects edge 73542
WARNING:  Loading of record 1710 failed: Spatial exception - geometry intersects edge 73533
WARNING:  Loading of record 1707 failed: Spatial exception - geometry intersects edge 73559
WARNING:  Loading of record 1709 failed: Spatial exception - geometry intersects edge 73512
Query returned successfully with no result in 10330315 ms.


45 errors above, almost 3hrs to run
*/




-- 4) SIRGAS 2000 and no tolerance 

--ALTER TABLE temp_geom_bahia DROP COLUMN tg_geom_dump;
SELECT topology.DropTopology('topo_bahia4');
SELECT topology.CreateTopology('topo_bahia4',4674);
select topology.addtopogeometrycolumn('topo_bahia4', 'public','temp_geom_bahia','tg_geom_dump2','POLYGON');
update temp_geom_bahia set tg_geom_dump2 = toTopoGeom(ST_Force2D(geom_dump),'topo_bahia4', 1 ) ;
-- ERROR:  Invalid edge (no two distinct vertices exist)
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment


DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_bahia SET tg_geom_dump2 = toTopoGeom(ST_Force2D(geom_dump),'topo_bahia4', 1 ) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;

/*
WARNING:  Loading of record 19090 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 19095 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 23253 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 638 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 834 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 578 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 584 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 594 failed: Could not get geometry of face 933
WARNING:  Loading of record 595 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 22597 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 570 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 617 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 618 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 547 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 502 failed: Could not convert shell geometry to GEOS: IllegalArgumentException: Points of LinearRing do not form a closed linestring
WARNING:  Loading of record 59 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4472 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4236 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4244 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4232 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4135 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 3941 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4481 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4483 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 1153 failed: SQL/MM Spatial exception - point not on edge
WARNING:  Loading of record 21183 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 21189 failed: SQL/MM Spatial exception - point not on edge
WARNING:  Loading of record 5184 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5245 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4979 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5061 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5153 failed: Could not find interior point for edge 7021: Self-intersection at or near point -38.690719399829185 -12.295546157226047
WARNING:  Loading of record 104 failed: SQL/MM Spatial exception - point not on edge
WARNING:  Loading of record 4966 failed: SQL/MM Spatial exception - point not on edge
WARNING:  Loading of record 4968 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5353 failed: Could not find interior point for edge 8164: Too few points in geometry component at or near point -44.393486588036296 -12.009698096773601
WARNING:  Loading of record 5306 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5341 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 18893 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 20375 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 2066 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 1998 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 2006 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 6289 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 6279 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5948 failed: SQL/MM Spatial exception - geometry crosses edge 11949
WARNING:  Loading of record 5831 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5808 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 5650 failed: Could not get geometry of face 5125
WARNING:  Loading of record 5662 failed: Could not get geometry of face 5544
WARNING:  Loading of record 5730 failed: Could not convert shell geometry to GEOS: IllegalArgumentException: Points of LinearRing do not form a closed linestring
WARNING:  Loading of record 4090 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4117 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 4079 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 1102 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 3862 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 3884 failed: SQL/MM Spatial exception - point not on edge
WARNING:  Loading of record 3823 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 3426 failed: Could not get geometry of face 6466
WARNING:  Loading of record 18794 failed: Invalid edge (no two distinct vertices exist)
WARNING:  Loading of record 3376 failed: Spatial exception - geometry intersects edge 17339
********** Error **********

*Then crashes the database , after running for 7min (427364ms)

*/



-- 5) UTM, 0.1m tolerance

SELECT topology.DropTopology('topo_bahia5');
SELECT topology.CreateTopology('topo_bahia5',32724);
SELECT topology.addtopogeometrycolumn('topo_bahia5', 'public','temp_geom_bahia','tg_geom_dump_utm3','POLYGON');
UPDATE temp_geom_bahia SET tg_geom_dump_utm3 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia5', 1, 0.1) ;
-- ERROR:  Spatial exception - geometry intersects edge 20187
-- CONTEXT:  PL/pgSQL function totopogeom(geometry,topogeometry,double precision) line 111 at FOR over SELECT rows
-- PL/pgSQL function totopogeom(geometry,character varying,integer,double precision) line 89 at assignment

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_bahia LOOP
    BEGIN
      UPDATE temp_geom_bahia SET tg_geom_dump_utm3 = toTopoGeom(ST_Force2D(geom_dump_utm),'topo_bahia5', 1, 0.1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;





------------------------------
-- Now with pprepair output
------------------------------



/* criando nova tabela */
CREATE TABLE temp_geom_ppr_bahia AS
SELECT 	uf, cod_set, gid, (ST_Dump(geom_ppr_rep_sVW_1m)).path AS id_dump, 
	(ST_Dump(geom_ppr_rep_sVW_10m)).geom AS geom_ppr_rep_sVW_1m_dump, 
	ST_Transform(  (ST_Dump(geom_ppr_rep_sVW_1m)).geom  ,32719) AS geom_ppr_rep_sVW_1m_dump_UTM 
FROM FROM setores_censitario_pprepair_final_r 
WHERE uf=29;


-- 1a) pprepair, UTM, 1m tolerance

SELECT topology.DropTopology('topo_ppr_bahia');
SELECT topology.CreateTopology('topo_ppr_bahia',32724);
SELECT topology.addtopogeometrycolumn('topo_ppr_bahia', 'public','temp_geom_ppr_bahia','tg_geom_ppr_rep_sVW_1m_dump_UTM','POLYGON');
UPDATE temp_geom_ppr_bahia SET tg_geom_ppr_rep_sVW_1m_dump_UTM = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_1m_dump_UTM),'topo_ppr_bahia', 1, 1) ;

DO $$DECLARE r record;
BEGIN
  FOR r IN SELECT * FROM temp_geom_ppr_bahia LOOP
    BEGIN
      UPDATE temp_geom_ppr_bahia SET tg_geom_ppr_rep_sVW_1m_dump_UTM = toTopoGeom(ST_Force2D(geom_ppr_rep_sVW_1m_dump_UTM),'topo_ppr_bahia', 1, 1) 
      WHERE gid= r.gid;
    EXCEPTION
      WHEN OTHERS THEN
        RAISE WARNING 'Loading of record % failed: %', r.gid, SQLERRM;
    END;
  END LOOP;
END$$;
