CREATE TABLE tabela_areas_perimetro_setores_original_pprepair2 AS
SELECT foo1.uf, 
       foo1.tipo, 
       foo1.cd_geocodi, 
       foo1.area_setor AS area_setor_original, 
       foo2.area_setor AS area_setor_pprepair,
       foo2.area_setor_pprepair_buffer121, foo2.area_setor_pprepair_buffer12int,
       abs(foo1.area_setor-foo2.area_setor                     ) AS dif_original_pprepair,
       abs(foo1.area_setor-foo2.area_setor_pprepair_buffer121  ) AS dif_original_pprepair_buffer121,
       abs(foo1.area_setor-foo2.area_setor_pprepair_buffer12int) AS dif_original_pprepair_buffer12int,
       foo1.perimetro_setor AS perimetro_setor_original, 
       foo2.perimetro_setor AS perimetro_setor_pprepair, 
       foo2.perimetro_setor_pprepair_buffer121, foo2.perimetro_setor_pprepair_buffer12int,
       abs(foo1.perimetro_setor-foo2.perimetro_setor                     ) AS dif_perimetro_original_pprepair, 
       abs(foo1.perimetro_setor-foo2.perimetro_setor_pprepair_buffer121  ) AS dif_perimetro_original_pprepair_buffer121,
       abs(foo1.perimetro_setor-foo2.perimetro_setor_pprepair_buffer12int) AS dif_perimetro_original_pprepair_buffer12int
FROM (SELECT uf,tipo,cd_geocodi,
      	ST_Area(ST_Transform(geom         ,utmzone(ST_Centroid(geom         )))) 	AS area_setor,
      	ST_Area(ST_Transform(geom_b1b2b1  ,utmzone(ST_Centroid(geom_b1b2b1  )))) 	AS area_setor_pprepair_buffer121,
      	ST_Area(ST_Transform(geom_b1b2_int,utmzone(ST_Centroid(geom_b1b2_int)))) 	AS area_setor_pprepair_buffer12int,
      	ST_Perimeter(ST_Transform(geom         ,utmzone(ST_Centroid(geom         )))) 	AS perimetro_setor,
      	ST_Perimeter(ST_Transform(geom_b1b2b1  ,utmzone(ST_Centroid(geom_b1b2b1  )))) 	AS perimetro_setor_pprepair_buffer121,
      	ST_Perimeter(ST_Transform(geom_b1b2_int,utmzone(ST_Centroid(geom_b1b2_int)))) 	AS perimetro_setor_pprepair_buffer12int
      FROM setores_censitario_pprepair_final_reparado_buffer
      ORDER BY uf,cd_geocodi) AS foo2
FULL OUTER JOIN
     (SELECT uf,tipo,cd_geocodi,
      ST_Area(ST_Transform(geomcorrigido,utmzone(ST_Centroid(geomcorrigido)))) AS area_setor,
      ST_Perimeter(ST_Transform(geomcorrigido,utmzone(ST_Centroid(geomcorrigido)))) AS perimetro_setor
    FROM setores_censitario_brasil
    ORDER BY uf,cd_geocodi) AS foo1
ON foo2.uf=foo1.uf
AND foo2.tipo=foo1.tipo
AND foo2.cd_geocodi=foo1.cd_geocodi ;




-- selecionando casos de mudanca para investigar no Postgis

select count(*) from tabela_areas_perimetro_setores_original_pprepair
drop table a_temp_probelmas_area;
CREATE TABLE a_temp_probelmas_area AS
SELECT foo1.*, pct_difdif
FROM setores_censitario_pprepair_final_reparado_buffer AS foo1
INNER JOIN (	select cd_geocodi, dif_perimetro_original_pprepair, dif_perimetro_original_pprepair_buffer121, dif_perimetro_original_pprepair_buffer12int,
		abs(dif_original_pprepair-dif_original_pprepair_buffer121)/area_setor_original as pct_difdif
		from tabela_areas_perimetro_setores_original_pprepair2  as foo1
		ORDER BY  abs(dif_original_pprepair-dif_original_pprepair_buffer121)/area_setor_original DESC
		limit 10) as foo2
ON foo1.cd_geocodi=foo2.cd_geocodi 




