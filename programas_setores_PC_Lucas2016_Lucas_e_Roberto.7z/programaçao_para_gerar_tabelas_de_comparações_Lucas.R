options("scipen" = 10)
library(ggplot2)
library(dplyr)
library(RPostgreSQL)

con <- dbConnect(dbDriver("PostgreSQL"), host='localhost',
                 port='5432', dbname='dados_espaciais',  password='liao', user='postgres')

# Lista as tabelas existentes na conex�o
dbListTables(con)
 
# Lista as colunas de uma determinada tabela
dbListFields(con,"sc2010_area_perimetro")
 
# Retorna uma determinada query 

round(dados_completo$dif_original_pprepair,2)


dados_completo <- dbGetQuery(con,"select * from sc2010_area_perimetro")

dados_completo %>% filter(dif_peri_ori_ppr_rep_svw_1m_p-dif_peri_ori_ppr_rep_p>0) %>% View()


dados_completo %>% filter(dif_peri_ori_ppr_rep_p< 2) %>%
ggplot(      aes(x=dif_peri_ori_ppr_rep_p,y=dif_peri_ori_ppr_rep_svw_10m_p)) +
  geom_point()

dados_completo %>% filter(dif_peri_ori_ppr_rep< 15000) %>%
  ggplot(      aes(x=dif_peri_ori_ppr_rep,y=dif_peri_ori_ppr_rep_svw_m)) +
  geom_point()


ggplot(d2, aes(x=dif_peri_ori_ppr_rep,y=dif_peri_ori_ppr_rep_svw_0m)) +
  geom_point()


dados_completo %>% filter(dif_peri_ori_ppr_rep_p< 0.5) %>%
ggplot(        aes(x=dif_peri_ori_ppr_rep,y=dif_peri_ori_ppr_rep_svw_1m_p)) +
  geom_point() + facet_wrap(~ uf )


ggplot(d2, aes(x=dif_peri_ori_ppr_rep,y=dif_peri_ori_ppr_rep_svw_1m  )) +
  geom_point()


ggplot(d2, aes(x=dif_peri_ori_ppr_rep,y=dif_peri_ori_ppr_rep_svw_1m)) +
  geom_point()


  geom_bar(stat = "identity")+coord_flip() + xlab('Diferen�a absoluta entre �rea\n original e reparada (metros quadrados)') + ylab('Frequ�ncia')



#### AREA
#dados <- subset(dados_completo , dif_original_pprepair != 0 & tipo =='URBANO' )
#dados <- subset(dados_completo , dif_original_pprepair != 0 & tipo =='RURAL' )

a <- table(cut(dados$dif_original_pprepair, include.lowest=T,
		breaks=c(min(dados$dif_original_pprepair,na.rm=T),1,5,10,25,50,100,125,150,175,200,225,250,275,300,500,1000,1500,2000,max(dados$dif_original_pprepair,na.rm=T)+1) ))

a <-data.frame(cbind(cbind(a),cbind(round(prop.table(a),4)),cbind(cumsum(a)),cbind(	cumsum(round(prop.table(a),4)))))

a$dif_area <- row.names(a)
row.names(a) <- NULL
names(a) <- c('Freq','Freq_Rel','Freq_Acum','Freq_Rel_Acum','dif_area')
a <- a[,c(5,1:4)]

a$dif_area <- factor(a$dif_area, levels=a$dif_area)


ggplot(a, aes(x=dif_area,y=Freq))+ geom_bar(stat = "identity")+coord_flip() + xlab('Diferen�a absoluta entre �rea\n original e reparada (metros quadrados)') + ylab('Frequ�ncia')
a2 <- subset(a, dif_area!= '[0.01,1]')
ggplot(a2, aes(x=dif_area,y=Freq))+ geom_bar(stat = "identity")+coord_flip() + xlab('Diferen�a absoluta entre �rea\n original e reparada (metros quadrados)') + ylab('Frequ�ncia')


####PERIMETRO
#dados <- subset(dados_completo , dif_perimetro_original_pprepair != 0 & tipo =='URBANO' )
#dados <- subset(dados_completo , dif_perimetro_original_pprepair != 0 & tipo =='RURAL' )

a <- table(cut( dados$dif_perimetro_original_pprepair, include.lowest=T,
			breaks=c(0.01,1,5,10,25,50,100,125,150,175,200,300,400,500,1000,10000,max( dados$dif_perimetro_original_pprepair,na.rm=T)+1) ))

a <-data.frame(cbind(cbind(a),cbind(round(prop.table(a),4)),cbind(cumsum(a)),cbind(	cumsum(round(prop.table(a),4)))))

a$dif_perimetro <- row.names(a)
row.names(a) <- NULL
names(a) <- c('Freq','Freq_Rel','Freq_Acum','Freq_Rel_Acum','dif_perimetro')
a <- a[,c(5,1:4)]

a$dif_perimetro <- factor(a$dif_perimetro, levels=a$dif_perimetro)

ggplot(a, aes(x=dif_perimetro,y=Freq))+ geom_bar(stat = "identity")+coord_flip()+xlab('Diferen�a absoluta entre perimetro original\n e reparada (metros)') + ylab('Frequ�ncia')


#### Area Sinal
#dados <- subset(dados_completo , dif_original_pprepair_sinal != 0 & tipo =='URBANO' )
#dados <- subset(dados_completo , dif_original_pprepair_sinal != 0 & tipo =='RURAL' )

a <- table(cut(dados$dif_original_pprepair_sinal, include.lowest=T,
		breaks=c(min(dados$dif_original_pprepair_sinal,na.rm=T),-2000,-1500,-1000,-500,-300,-175,-150,-125,-100,-50,-25,-10,-5,-1,-0.01,0.01,1,5,10,25,50,100,125,150,175,300,500,1000,1500,2000,max(dados$dif_original_pprepair_sinal,na.rm=T)+1) ))

a <-data.frame(cbind(cbind(a),cbind(round(prop.table(a),4)),cbind(cumsum(a)),cbind(	cumsum(round(prop.table(a),4)))))

a$dif_area <- row.names(a)
row.names(a) <- NULL
names(a) <- c('Freq','Freq_Rel','Freq_Acum','Freq_Rel_Acum','dif_area')
a <- a[,c(5,1:4)]

a$dif_area <- factor(a$dif_area, levels=a$dif_area)


ggplot(a, aes(x=dif_area,y=Freq))+ geom_bar(stat = "identity")+coord_flip() + xlab('Diferen�a entre �rea original\n e reparada (metros quadrados)') + ylab('Frequ�ncia')

### Perimetro sinal
#dados <- subset(dados_completo , dif_perimetro_original_pprepair_sinal != 0 & tipo =='URBANO' )
#dados <- subset(dados_completo , dif_perimetro_original_pprepair_sinal != 0 & tipo =='RURAL' )

a <- table(cut( dados$dif_perimetro_original_pprepair_sinal, include.lowest=T,
			breaks=c(min( dados$dif_perimetro_original_pprepair_sinal,na.rm=T),-10000,-1000,-500,-400,-300,-200,-175,-150,-125,-100,-50,-25,-10,-5,-1,-0.01,0.01,1,5,10,25,50,100,125,150,175,200,300,400,500,1000,max( dados$dif_perimetro_original_pprepair_sinal,na.rm=T)+1) ))

a <-data.frame(cbind(cbind(a),cbind(round(prop.table(a),4)),cbind(cumsum(a)),cbind(	cumsum(round(prop.table(a),4)))))

a$dif_perimetro <- row.names(a)
row.names(a) <- NULL
names(a) <- c('Freq','Freq_Rel','Freq_Acum','Freq_Rel_Acum','dif_perimetro')
a <- a[,c(5,1:4)]

a$dif_perimetro <- factor(a$dif_perimetro, levels=a$dif_perimetro)

ggplot(a, aes(x=dif_perimetro,y=Freq))+ geom_bar(stat = "identity")+coord_flip()+xlab('Diferen�a absoluta entre perimetro original\n e reparada (metros)') + ylab('Frequ�ncia')


########################################
###########################################
head(dados_completo)
#temp <- subset(dados_completo, dif_original_pprepair_sinal != 0 & tipo =='URBANO')
#temp <- subset(dados_completo, dif_original_pprepair_sinal != 0 & tipo =='RURAL')


razao <-  round((temp$dif_original_pprepair_sinal/temp$area_setor_original)*100,2)
a <- table(cut( razao, include.lowest=T,
			breaks=seq(-1,1,0.1) ))

a <-data.frame(cbind(cbind(a),cbind(round(prop.table(a),4)),cbind(cumsum(a)),cbind(	cumsum(round(prop.table(a),4)))))

a$variacao_percentual <- row.names(a)
row.names(a) <- NULL
names(a) <- c('Freq','Freq_Rel','Freq_Acum','Freq_Rel_Acum','Varia��o_Percentual')
a <- a[,c(5,1:4)]
a[[1]] <- factor(a[[1]], levels=a[[1]])
ggplot(a, aes(x=Varia��o_Percentual,y=Freq))+ geom_bar(stat = "identity")+coord_flip()+xlab('Varia��o percentual em rela��o a �rea original') + ylab('Frequ�ncia')

############

dados <- transform(dados_completo, razao = round((dif_original_pprepair/area_setor_original)*100,2))


ggplot(dados,aes(razao,dif_original_pprepair)) + geom_point() + facet_wrap(~tipo, scales='free')
dados2 <- subset(dados,dif_original_pprepair < 500000)
ggplot(dados2,aes(razao,dif_original_pprepair)) + geom_point() + facet_wrap(~tipo,scales='free')
dados3 <- subset(dados,dif_original_pprepair < 500000 & razao <=0.5)
ggplot(dados3,aes(razao,dif_original_pprepair)) + geom_point() + facet_wrap(~tipo,scales='free')





