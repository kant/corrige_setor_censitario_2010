﻿CREATE TABLE estados_geral AS
SELECT uf,ST_Union(geom5) AS geom6 
FROM    (SELECT uf, St_MakePolygon(ST_ExteriorRing(geom4)) AS geom5 FROM 
        (SELECT uf, (ST_Dump(geom3)).path ,(ST_Dump(geom3)).geom  AS geom4 
            FROM   (SELECT uf, ST_Union(ST_MakeValid(geom2)) AS geom3
                FROM  (    SELECT substring(cd_geocodi from 1 for 2) AS uf, gid, (ST_Dump(geom)).geom AS geom2
                    FROM setores_censitario_pprepair_final
                    ) AS foo
                GROUP BY uf) f002) AS foo2
    WHERE GeometryType(geom4) in ('POLYGON')) AS foo3
GROUP BY uf;

GRANT ALL PRiVILEGES ON estados_geral TO r342471958; 
CREATE INDEX estados_geral_spatial_index ON estados_geral USING GIST (geom6); 
CLUSTER estados_geral USING estados_geral_spatial_index;
ANALYZE estados_geral;

CREATE TABLE tabela_geral_triangulos AS
(SELECT * FROM zzzz_teste_triangulos11)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos12)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos13)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos14)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos15)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos16)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos17)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos21)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos22)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos23)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos24)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos25)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos26)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos27)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos28)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos29)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos31)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos32)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos33)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos35)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos41)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos42)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos43)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos50)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos51)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos52)
UNION ALL
(SELECT * FROM zzzz_teste_triangulos53)

GRANT ALL PRiVILEGES ON tabela_geral_triangulos TO r342471958; 
CREATE INDEX tabela_geral_triangulos_spatial_index ON tabela_geral_triangulos USING GIST (geom); 
CLUSTER tabela_geral_triangulos USING tabela_geral_triangulos_spatial_index;
ANALYZE tabela_geral_triangulos;



select * from tabela_geral_triangulos limit 100

select count(*) from tabela_geral_triangulos  WHERE tags!= 1



#Selecionando, dos triangulos de output do pprepair, apenas os que sao interiores ao estado e que sao de gaps ou overlaps.
DROP TABLE pprepair_output_triangulos_internosUf_problema
CREATE TABLE pprepair_output_triangulos_internosUf_problema as
SELECT t.* 
from estados_geral2 AS e, 
     (SELECT * FROM tabela_geral_triangulos WHERE tags!= 1) AS t 
WHERE t.uf = e.uf AND ST_Contains(e.geom6,t.geom)=true
#acima, roda em aprox 1h30  (5240035ms)
CREATE INDEX pprepair_output_triangulos_internosUf_problema_index ON pprepair_output_triangulos_internosUf_problema USING GIST (uf, geom); 
CLUSTER pprepair_output_triangulos_internosUf_problema USING pprepair_output_triangulos_internosUf_problema_index;


#Encontrando intersecoes entre setores censitarios e triangulos (de erro e internos aos estados) do pprepair
CREATE TABLE pprepair_output_triangulosProbl_setor AS
select 	t.uf, t.gid, s.cd_geocodi as cod_setor, tags, 
	t.geom, ST_Intersection(t.geom,s.geom) AS intersec_geom, GeometryType( ST_Intersection(t.geom,s.geom) ) AS intersec_type
FROM 	pprepair_output_triangulos_internosUf_problema as t,
	setores_censitario_pprepair_final2 as s
WHERE 	t.uf=s.uf AND
	ST_Intersects(t.geom,s.geom) = TRUE


#aqui esta dando erro
ERROR:  Error performing intersection: TopologyException: Input geom 0 is invalid: Self-intersection at or near point -40.471320999999989 -15.853078997517798 at -40.471320999999989 -15.853078997517798
********** Error **********
ERROR: Error performing intersection: TopologyException: Input geom 0 is invalid: Self-intersection at or near point -40.471320999999989 -15.853078997517798 at -40.471320999999989 -15.853078997517798
SQL state: XX000


#Testando A validade dos triangulos e dos setores corrigidos:

select ST_IsValid(geom), count(*) 
from pprepair_output_triangulos_internosUf_problema
group by ST_IsValid(geom)

f;  23857
t;3140533

create table temp_triang_invalidos AS
select *  from pprepair_output_triangulos_internosUf_problema
where ST_IsValid(geom)=false



select tags, ST_IsValid(geom), count(*) 
from pprepair_output_triangulos_internosUf_problema
group by tags, ST_IsValid(geom)

tags;is_valid;count
0;f;8784
3;t;1679
0;t;1565983
3;f;597
2;f;14476
2;t;1572869
4;t;2


select uf, ST_IsValid(geom), count(*) 
from pprepair_output_triangulos_internosUf_problema
group by uf, ST_IsValid(geom)
order by ST_IsValid(geom), desc count(*) 



select ST_IsValid(geom), count(*) 
from tabela_geral_triangulos
group by ST_IsValid(geom)

f;   49098
t;31159318

select tags, ST_IsValid(geom), count(*) 
from tabela_geral_triangulos
group by tags, ST_IsValid(geom)
order by ST_IsValid(geom),  count(*) desc






select ST_IsValid(geom), count(*) 
from setores_censitario_pprepair_final
group by ST_IsValid(geom)

f;1573
t;321467




